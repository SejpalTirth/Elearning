import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CourseApiService } from '../../services/course-api';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-course',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-course.html',
  styleUrls: ['./add-course.css']
})
export class AddCourseComponent {

  course = {
    title: '',
    description: ''
  };

  saving = false;

  constructor(
    private courseApi: CourseApiService,
    private router: Router
  ) {}

  submit() {
    this.saving = true;

    this.courseApi.addCourse(this.course).subscribe({
      next: () => {
        alert("Course added successfully!");
        this.router.navigate(['/courses']);
      },
      error: (err) => {
        console.error(err);
        alert("Failed to add course.");
        this.saving = false;
      }
    });
  }
}
