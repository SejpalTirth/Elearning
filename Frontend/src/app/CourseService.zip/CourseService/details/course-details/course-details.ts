import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CourseApiService } from '../../services/course-api';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-course-details',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './course-details.html',
  styleUrls: ['./course-details.css']
})
export class CourseDetailsComponent implements OnInit {

  course: any = null;

  constructor(
    private route: ActivatedRoute,
    private courseApi: CourseApiService
  ) {}

  ngOnInit(): void {
  const id = Number(this.route.snapshot.paramMap.get('id'));
  this.loadCourse(id);
}

loadCourse(id: number) {
  this.courseApi.getById(id).subscribe({
    next: (res) => this.course = res,
    error: (err) => console.error(err)
  });
}
}
