import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CourseApiService {


  private http = inject(HttpClient);

  // Your actual Gateway endpoint (as shown in Swagger)
  private baseUrl = 'https://localhost:7249/api/GatewayCourse';

  // GET all courses
  getAll(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl);
  }

  // GET course by ID
  getById(id: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/${id}`);
  }

  // POST: Add new course
  addCourse(payload: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, payload);
  }
}
