import { Routes } from '@angular/router';

import { ListCoursesComponent } from './list/list-courses';
import { CourseDetailsComponent } from './details/course-details';
import { AddCourseComponent } from './add/add-course';

export const COURSE_ROUTES: Routes = [
  { path: '', component: ListCoursesComponent },
  { path: 'add/new', component: AddCourseComponent },
  { path: ':id', component: CourseDetailsComponent }
];
